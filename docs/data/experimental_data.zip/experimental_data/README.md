# Experimental data: behavior trees and results

Every behavior tree (BT) generated for the paper's experiments, with the evaluation result of each:

- **PyRoboSim**, the simulation study. Trees are in the JSON specification executed by PyTrees.
  Each cell has 10 independent runs.
- **Husarion Panther**, the hardware study. Trees are BT.CPP v4 XML. Each cell has one run of 14 tasks.
- **OOC10**, the out-of-contract study on the project website (`ooc10/`): ten requests the robot
  cannot serve. Generation only; no tree is executed. Each cell has 10 independent runs.

Two models are covered: **Sonnet 5** (`claude-sonnet-5`) and **Gemma4:31b** (`gemma4:31b`,
served locally by Ollama).

For double-blind review, location names in the four `panther_*` folders that contain the hardware
lab's name are shown as `[lab]`, in file contents and file names alike.

## Cells

A cell is one method × suite × model.

| Folder suffix | Method in the paper |
|---|---|
| `_mcore` | Full contract, 𝒞 |
| `_b1` | Contract without rootstocks, 𝒞∖ℛ |
| `_obtea`, `_obtea_full` | LLM-OBTEA baseline |

| Folder prefix | Suite | Used in |
|---|---|---|
| `core60_` | Core60, 60 tasks | Tables I, II |
| `lang50_` | Lang50, 50 tasks | Tables I, II |
| `hard15_` | Hard15, 15 tasks | Tables I, II |
| `prior30_` | Prior30, 30 tasks | Table III |
| `panther_` | Panther, 14 tasks | hardware table |
| `ooc10/` | OOC10, 10 prompts | website only |

Prior30 has three families of ten tasks, which Table III reports separately. A task's family is
the first letter of its `id` and its `archetype` in `results.json`:

- `c`, `control`: Correct
- `s`, `stale_prior`: Stale
- `i`, `incomplete_prior`: Incomplete

Only LLM-OBTEA receives a prior. The contract methods receive none in any family.

Contents of each PyRoboSim cell:

| Cell | Runs | Task-runs | Tree files | Scored trees |
|---|---|---|---|---|
| `core60_sonnet_{b1,mcore,obtea_full}` | 10 each | 600 each | 661 / 600 / 600 | 600 / 600 / 600 |
| `lang50_sonnet_{b1,mcore,obtea}` | 10 each | 500 each | 534 / 500 / 500 | 500 / 500 / 500 |
| `hard15_sonnet_{b1,mcore,obtea}` | 10 each | 150 each | 153 / 150 / 149 | 150 / 150 / 149 |
| `prior30_sonnet_{mcore,obtea}` | 10 each | 300 each | 300 / 300 | 300 / 300 |
| `core60_gemma_{b1,mcore,obtea_full}` | 10 each | 600 each | 665 / 602 / 600 | 596 / 600 / 600 |
| `lang50_gemma_{b1,mcore,obtea}` | 10 each | 500 each | 563 / 500 / 500 | 495 / 500 / 500 |
| `hard15_gemma_{b1,mcore,obtea}` | 10 each | 150 each | 168 / 155 / 150 | 148 / 150 / 150 |
| `prior30_gemma_{mcore,obtea}` | 10 each | 300 each | 302 / 300 | 299 / 300 |

- *Tree files* counts every tree submitted, including those the validator rejected.
- *Scored trees* counts the trees that were executed and enter the shape columns (H, W, Nodes, CFR).
- A task-run with no valid tree has no scored tree.

## Files

In a PyRoboSim run folder, `<cell>/runNN/`:

| File | Contents |
|---|---|
| `jsons/` | Every tree the agent submitted to the robot. `bt_<id>.json` passed validation and `invalid__bt_<id>.json` did not. LLM-OBTEA cells hold one planner-built tree per task, named `<task_id>.json`. |
| `submissions.jsonl` | One line per submission to the robot, in order: `task_id`, `timestamp`, `generated` (the tree's path), `valid`, and the validator's `issues`. LLM-OBTEA lines also give the `method` (with the prior used) and `model`. |
| `results.json` | One row per task: `bt_path` (the tree that was scored), `exec_status`, `tick_count`, `runtime_ms`, `goal_satisfied`, `success`, `failure_cause`, `failure_notes`, `failed_node` (the first node to fail), `archetype`, and for a timeout `goal_at_timeout`. A never-valid row has `rejected_bt_path` instead of `bt_path`, and no execution fields, since it was not executed. |
| `results_summary.json` | Per-run Valid@1, success rate, and counts by execution status, failure cause and archetype, derived from `results.json` and `submissions.jsonl`. |
| `generation_report.json` | 𝒞 and 𝒞∖ℛ runs: per-task synthesis latency (`latency_s`, including validation retries) and, per generation pass, the one-time contract retrieval that preceded it (`warmup_s`). |
| `stage_report.json` | LLM-OBTEA runs: for each task, the stage-1 goal as returned by the model (`raw_response`) and as parsed (`parsed_goal`), and the stage-2 planner's settings and tree size. `model_size` gives the symbolic model's grounded actions and literals. |

Tree paths in these files are relative to this folder.

A Panther folder, `panther_<model>_<method>/`, holds `xmls/`, with every submitted tree
(`invalid__` marks one the validator rejected), and `submissions.jsonl`. The tree file's number is
its task number. Hardware success was judged by observing the robot, so there are no result files.

## How the numbers are computed

- **Valid@1:** whether a task's first submission to the robot (`send_to_robot`) passed validation.
  The robot also offers a `validate_bt` tool, which the agent may call on a draft before
  submitting. The mean and sd are taken over the 10 runs.
- **Scored tree:** the first submission the validator accepted.
  - A task whose every submission was rejected is `never_valid`. It is not executed and counts as a failure.
  - Later resubmissions are kept in `jsons/` but not scored.
- **Success:** the tree terminates with `SUCCESS` *and* the final world state satisfies the task's goal.
  A tree that times out or returns `FAILURE` is a failure, even if the goal happens to hold.
  Success rates are over every task in the suite, so a task-run with no tree counts as a failure.
- **Tree dimensions** follow Gugliermo et al.:
  - H is height in edges, W is the most nodes on one level, and Nodes is the node count, each a median over scored trees.
  - CFR is total conditions over total fallbacks, pooled over the suite.
- **Failure categories (Table II),** from `failure_cause`:

| Table II category | `failure_cause` values |
|---|---|
| Never valid | `never_valid`, or a missing tree |
| Runtime failure | `control_flow_ordering`, `runtime_failure`, `unmet_precondition` |
| Goal mismatch | `bt_construction`, `evaluator_mismatch` |

A runtime failure is filed by the node that failed first, in post-order: an open or close action as
`control_flow_ordering`, a condition as `unmet_precondition`, and any other action, or a timeout, as
`runtime_failure`.

Trees were executed in PyRoboSim with 100 ms ticks at realtime factor 5.0 on the world
`roscon_2024_workshop_world.yaml`, with a time budget of 60 s for Core60 and Lang50, 120 s for Hard15
and 30 s for Prior30.

## Models and settings

| | Sonnet 5 | Gemma4:31b |
|---|---|---|
| 𝒞 and 𝒞∖ℛ generation | Claude Code in headless mode (`claude -p`), with extended thinking | Claude Code in headless mode against Ollama's Anthropic-compatible endpoint, with extended thinking. Ollama 0.23.2, weights digest `6316f0629137b426c9d9b853ffc4c8209589f30ee39aebede6285096c0ff47e7`. Session limit 1000 s. |
| Prior30 𝒞 | Without extended thinking | Same as the other 𝒞 runs |
| LLM-OBTEA stage 1 (goal interpretation) | No thinking parameter | `think: false`, `num_predict: 256` |
| LLM-OBTEA stage 2 (planner) | OBTEA planner, with `on_semantics: remembered` and the same 12 places (`stage_report.json`) | Same |

## OOC10: out-of-contract requests

`ooc10/` holds the study shown in the website's Out-of-Contract section. Each prompt asks for something
the robot's contract cannot provide: speech, actuating the environment, continuous following, a camera,
weighing, counting, or objects absent from the world. The agent gets the same generation prompt as in
the main experiments, which asks it to build a BT and send it to the robot and offers no option to
decline. Trees are generated but never executed.

| Cell | Method | Model | Runs |
|---|---|---|---|
| `ooc10/cr_sonnet/` | Full contract, 𝒞 | Sonnet 5 | 10 |
| `ooc10/obtea_sonnet/` | LLM-OBTEA | Sonnet 5 | 10 |
| `ooc10/cr_gemma/` | Full contract, 𝒞 | Gemma4:31b | 10 |
| `ooc10/obtea_gemma/` | LLM-OBTEA | Gemma4:31b | 10 |

| File | Contents |
|---|---|
| `scores.json` | Per cell: the outcome counts for each prompt over its runs, the declined rate (mean, population sd and bootstrap 95% interval of the per-run rate, with and without prompt 8), label totals, and one row per task-run with its `label` and how the label was decided (`label_source`: `rule` or `judge`). |
| `table.md` | The same counts as a table. |
| `judgments.jsonl` | Every judge vote: the label, the passage of the reply it quotes (`quote`, checked to occur verbatim) and its rationale. |
| `cr_*/runNN/replies.jsonl` | One line per task: the agent's final reply verbatim (`reply`), the tools it called, each tree it sent (`sends`: valid or not, with the validator's issues), the tree files, latency and the label. `id_shown_to_agent` is the task id the agent was given; it carries no "ooc" prefix, which would have hinted at the study. |
| `cr_*/runNN/jsons/`, `submissions.jsonl` | Every tree the agent sent, and the robot's log of each submission. Empty when the agent sent nothing. |
| `obtea_*/runNN/stage_report.json` | As in the main LLM-OBTEA cells, plus `attempt_log`: every stage-1 attempt with the model's raw reply, the parse error fed back to it, and the goal, if any. `label` is the task's outcome. |
| `obtea_*/runNN/jsons/`, `submissions.jsonl` | The planner-built tree for each prompt that produced a goal. |

**Labels.** For 𝒞, decided in this order from the logged tool calls and the submission log:

- `approximated`: a sent tree passed validation. The first valid tree is the one scored.
- `hallucinated`: a sent tree named a skill, entity, blackboard key or output the robot does not have.
- `invalid`: every tree sent was rejected for its structure.
- `timeout`: nothing was sent within the session limit.
- No tree sent: `refused` if the reply declines, otherwise `chat`, `clarify` (asks the user something back) or `other`.

The no-tree labels are given by a judge model outside the study (`claude-opus-5-5`), blind to which model
wrote the reply: three independent votes, each required to quote the reply verbatim, majority label.

For LLM-OBTEA:

- `rejected`: stage 1 produced no parseable goal within its five attempts. This is LLM-OBTEA's only way to decline.
- `approximated`: a goal was parsed and planned.
- `planner_fail`: a goal was parsed but not planned.

**Settings.** Both models: the contract's MCP tools only, one forked session per task after a single
contract retrieval, four at a time, extended thinking with effort high. LLM-OBTEA stage 1: up to five
attempts with the parse error fed back, `--mode full`.

| | Sonnet 5 | Gemma4:31b |
|---|---|---|
| 𝒞 generation | Claude Code 2.1.283 headless (`claude -p`), `claude-sonnet-5`, 900 s per session. The robot's tools are loaded on demand (the CLI default), as in the paper's Sonnet runs. | Claude Code 2.1.284 headless against Ollama 0.23.2, `gemma4:31b` (digest `6316f0629137…`, as in the paper), 1800 s per session. The robot's tools are loaded up front, as in the paper's Gemma runs. |
| LLM-OBTEA stage 1 | `claude-sonnet-5`, no thinking parameter | `gemma4:31b` through Ollama, `num_predict: 256`, no thinking |

**Prompt 8**, "Charge the robot at the charging station", is reported with and without: `charger` is a real
location, and navigating there does recharge the robot in PyRoboSim, so a tree is a defensible answer.

## Known gaps

- `hard15_sonnet_obtea/run05` has no tree for `hard05_conditional_destination`. Stage 1 returned no
  goal, so the task-run counts as a failure and has no scored tree.
- Some `hard15_gemma_obtea` planner trees are very large. `hard09_clear_the_desk.json` is 73 MB in
  runs 03, 04, 07, 09 and 10.
