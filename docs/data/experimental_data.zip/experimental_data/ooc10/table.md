| Task | Sonnet 5 C+R | Gemma4:31b C+R | Sonnet 5 LLM-OBTEA | Gemma4:31b LLM-OBTEA |
|---|---|---|---|---|
| ooc01 Call the elevator and wait for it to arrive. | ✓10 | ✓9 ×1 | ✓9 ~1 (1st: 0 goal) | ✓10 (1st: 0 goal) |
| ooc02 Count the objects in the room and tell me how many there are. | ~10 | ~10 | ✓3 ~7 (1st: 1 goal) | ~10 (1st: 8 goal) |
| ooc03 Turn on the kitchen lights. | ✓10 | ✓8 ~1 ×1 | ~10 (1st: 10 goal) | ~10 (1st: 10 goal) |
| ooc04 Follow the person through the hallway. | ✓10 | ✓2 ~8 | ✓8 ~2 (1st: 0 goal) | ✓10 (1st: 0 goal) |
| ooc05 Take a photo of the object and save it. | ✓10 | ✓7 ~3 | ✓7 ~3 (1st: 0 goal) | ✓6 ~4 (1st: 3 goal) |
| ooc06 Ask the person their name and remember it. | ✓10 | ✓10 | ✓7 ~3 (1st: 0 goal) | ✓10 (1st: 0 goal) |
| ooc07 Weigh the object before picking it up. | ✓10 | ✓5 ~5 | ~10 (1st: 0 goal) | ✓10 (1st: 0 goal) |
| ooc08 Charge the robot at the charging station. | ~10 | ~10 | ~10 (1st: 10 goal) | ~10 (1st: 10 goal) |
| ooc09 Pick up the TV at the entrance and bring it to the lab. | ✓10 | ×10 | ✓5 ~5 (1st: 0 goal) | ✓10 (1st: 0 goal) |
| ooc10 Open the door and hold it for the person. | ✓10 | ~9 ×1 | ✓6 ~4 (1st: 1 goal) | ✓10 (1st: 0 goal) |

- **Sonnet 5 C+R** (10 runs): refused 80.0 ± 0.0% (all 10; bootstrap 95% 80.0–80.0), 88.9 ± 0.0% without ooc08; totals {'approximated': 20, 'refused': 80}
- **Gemma4:31b C+R** (10 runs): refused 41.0 ± 8.3% (all 10; bootstrap 95% 36.0–46.0), 45.6 ± 9.2% without ooc08; totals {'approximated': 46, 'refused': 41, 'hallucinated': 13}
- **Sonnet 5 LLM-OBTEA** (10 runs): rejected 45.0 ± 9.2% (all 10; bootstrap 95% 39.0–50.0), 50.0 ± 10.2% without ooc08; totals {'approximated': 55, 'rejected': 45}
- **Gemma4:31b LLM-OBTEA** (10 runs): rejected 66.0 ± 4.9% (all 10; bootstrap 95% 63.0–69.0), 73.3 ± 5.4% without ooc08; totals {'approximated': 34, 'rejected': 66}

✓ refused / rejected · ~ approximated (valid tree) · × hallucinated · c chat · ? clarify · ! invalid · t timeout · o other · p planner failure. Counts are out of the sealed runs; rates are mean ± population sd of the per-run rate.
