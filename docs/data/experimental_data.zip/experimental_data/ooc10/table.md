| Task | Sonnet 5 C+R | Sonnet 5 LLM-OBTEA |
|---|---|---|
| ooc01 Call the elevator and wait for it to arrive. | ✓10 | ✓9 ~1 (1st: 0 goal) |
| ooc02 Count the objects in the room and tell me how many there are. | ~10 | ✓3 ~7 (1st: 1 goal) |
| ooc03 Turn on the kitchen lights. | ✓10 | ~10 (1st: 10 goal) |
| ooc04 Follow the person through the hallway. | ✓10 | ✓8 ~2 (1st: 0 goal) |
| ooc05 Take a photo of the object and save it. | ✓10 | ✓7 ~3 (1st: 0 goal) |
| ooc06 Ask the person their name and remember it. | ✓10 | ✓7 ~3 (1st: 0 goal) |
| ooc07 Weigh the object before picking it up. | ✓10 | ~10 (1st: 0 goal) |
| ooc08 Charge the robot at the charging station. | ~10 | ~10 (1st: 10 goal) |
| ooc09 Pick up the TV at the entrance and bring it to the lab. | ✓10 | ✓5 ~5 (1st: 0 goal) |
| ooc10 Open the door and hold it for the person. | ✓10 | ✓6 ~4 (1st: 1 goal) |

- **Sonnet 5 C+R** (10 runs): refused 80.0 ± 0.0% (all 10; bootstrap 95% 80.0–80.0), 88.9 ± 0.0% without ooc08; totals {'refused': 80, 'approximated': 20}
- **Sonnet 5 LLM-OBTEA** (10 runs): rejected 45.0 ± 9.2% (all 10; bootstrap 95% 39.0–50.0), 50.0 ± 10.2% without ooc08; totals {'rejected': 45, 'approximated': 55}

✓ refused / rejected · ~ approximated (valid tree) · × hallucinated · c chat · ? clarify · ! invalid · t timeout · o other · p planner failure. Counts are out of the sealed runs; rates are mean ± population sd of the per-run rate.
